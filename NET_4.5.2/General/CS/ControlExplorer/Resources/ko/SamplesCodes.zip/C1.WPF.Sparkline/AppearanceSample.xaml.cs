﻿using C1.WPF.Sparkline;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SparklineSamples
{
    /// <summary>
    /// Interaction logic for AppearanceSample.xaml
    /// </summary>
    public partial class AppearanceSample : UserControl
    {
        public AppearanceSample()
        {
            InitializeComponent();
        }
    }
}
