﻿using System.Threading;
using System.Windows.Controls;

namespace BasicControls
{
    /// <summary>
    /// Interaction logic for DateTimePickerAdvanced.xaml
    /// </summary>
    public partial class DateTimePickerAdvanced : UserControl
    {
        public DateTimePickerAdvanced()
        {
            InitializeComponent();
            // add some custom formats to dateFormatCombo
            dateFormatCombo.Items.Add("yyyy/MM/dd");
            dateFormatCombo.Items.Add("yyyy-MM-dd");
            int monthNameLength = Thread.CurrentThread.CurrentUICulture.DateTimeFormat.AbbreviatedMonthNames[1].Length;
            if (monthNameLength != 3)
            {
                // (most cultures use 3 symbols for abbreviated month name, but not all. For example, Japanese culture uses single digit)
                // in this case it's not safe to use abbreviated month names, as we can't guarantee the correct mask and correct parsing for the text input
                // use format with numbers instead
                dateFormatCombo.Items.Add("yyyy年MM月dd日");
            }
            else
            {
                dateFormatCombo.Items.Add("yyyy MMM dd");
            }
            dateFormatCombo.SelectedIndex = 0;

            // add some custom formats to timeFormatCombo
            timeFormatCombo.Items.Add("HH:mm");
            timeFormatCombo.Items.Add("HH-mm-ss");
            timeFormatCombo.Items.Add("tt h:mm:ss");
            timeFormatCombo.Items.Add("h時mm分");
            timeFormatCombo.SelectedIndex = 0;
        }

        private void dateFormatCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // use custom date format from dateFormatCombo.SelectedItem
            dateTimePicker.CustomDateFormat = (string)dateFormatCombo.SelectedItem;
            // use text mask acceptable for the selected date format
            if (dateFormatCombo.SelectedIndex == 0)
            {
                // format is "yyyy/MM/dd"
                dateTimePicker.DateMask = "0000/00/00";
            }
            else if (dateFormatCombo.SelectedIndex == 1)
            {
                // format is "yyyy-MM-dd"
                dateTimePicker.DateMask = "0000-00-00";
            }
            else
            {
                if (dateFormatCombo.SelectedItem.ToString() == "yyyy MMM dd")
                {
                    dateTimePicker.DateMask = "0000 LLL 00";
                }
                else
                {
                    // format is "yyyy年MM月dd日"
                    dateTimePicker.DateMask = "0000年00月00日";
                }
            }
        }

        private void timeFormatCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // use custom time format from timeFormatCombo.SelectedItem
            dateTimePicker.CustomTimeFormat = (string)timeFormatCombo.SelectedItem;
            // use text mask acceptable for the selected time format
            if (timeFormatCombo.SelectedIndex == 0)
            {
                // format is "HH:mm"
                dateTimePicker.TimeMask = "00:00";
            }
            else if (timeFormatCombo.SelectedIndex == 1)
            {
                // format is "HH-mm-ss"
                dateTimePicker.TimeMask = "00-00-00";
            }
            else if (timeFormatCombo.SelectedIndex == 2)
            {
                if (!string.IsNullOrEmpty(Thread.CurrentThread.CurrentUICulture.DateTimeFormat.AMDesignator))
                {
                    // format is "tt h:mm:ss"
                    dateTimePicker.TimeMask = "aa 00:00:00";
                }
                else
                {
                    // format is "tt h:mm:ss", but current culture has no am/pm designators
                    dateTimePicker.TimeMask = "00:00:00";
                }
            }
            else
            {
                // format is "h時mm分"
                dateTimePicker.TimeMask = "00時00分";
            }
        }
    }
}
