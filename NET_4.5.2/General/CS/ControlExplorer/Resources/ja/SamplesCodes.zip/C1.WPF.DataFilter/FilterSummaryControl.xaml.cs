﻿using C1.DataCollection;
using C1.DataFilter;
using C1.WPF.DataFilter;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FilterSummary
{
    /// <summary>
    /// Interaction logic for FilterSummarySample.xaml
    /// </summary>
    public partial class FilterSummarySample : UserControl
    {
        C1DataCollection<Car> data = new C1DataCollection<Car>(GetCars());

        public FilterSummarySample()
        {
            InitializeComponent();

            flexGrid.ItemsSource = data;
            c1DataFilter1.DataSource = data;

            foreach (ChecklistFilter filter in c1DataFilter1.Filters.Where(f => f is ChecklistFilter))
                filter.SelectAll();
        }

        public static IEnumerable<Car> GetCars()
        {
            var carsTable = GetDataTableCars();
            foreach (DataRow row in carsTable.Rows)
            {
                yield return new Car
                {
                    Brand = row.Field<string>("Brand"),
                    Category = row.Field<string>("Category"),
                    Description = row.Field<string>("Description"),
                    Liter = row.Field<double>("Liter"),
                    Model = row.Field<string>("Model"),
                    Picture = row.Field<byte[]>("Picture"),
                    Price = row.Field<double>("Price"),
                    TransmissAutomatic = row.Field<string>("TransmissAutomatic"),
                    ID = row.Field<int>("ID")
                };
            }
        }

        static DataTable GetDataTableCars()
        {
            string rs = "select * from Cars;";
            string cn = GetConnectionString();
            OleDbDataAdapter da = new OleDbDataAdapter(rs, cn);
            DataTable dt = new DataTable("Cars");
            da.Fill(dt);
            return dt;
        }

        static string GetConnectionString()
        {
            string path = Environment.GetFolderPath(Environment.SpecialFolder.Personal) + @"\ComponentOne Samples\Common";
            string conn = @"provider=microsoft.jet.oledb.4.0;data source={0}\c1nwind.mdb;";
            return string.Format(conn, path);
        }

        async void Button_ClickAsync(object sender, RoutedEventArgs e)
        {
            await c1DataFilter1.ApplyFilterAsync();
        }

        void CheckBox_Click(object sender, RoutedEventArgs e)
        {
            c1DataFilter1.AutoApply = (sender as CheckBox).IsChecked.Value;
        }

        private void C1DataFilter1_FilterAutoGenerating(object sender, FilterAutoGeneratingEventArgs e)
        {
            foreach (Filter f in c1DataFilter1.Filters)
            {
                if (f.PropertyName == "Brand")
                {
                    var brandFilter = f as ChecklistFilter;
                    brandFilter.FilterSummary.Label = "Models:";
                    brandFilter.FilterSummary.PropertyName = "Brand";
                    brandFilter.FilterSummary.AggregateType = C1.DataFilter.AggregateType.Count;
                }

                if (f.PropertyName == "Model")
                {
                    var modelFilter = f as ChecklistFilter;
                    modelFilter.FilterSummary.AggregateType = C1.DataFilter.AggregateType.Max;
                    modelFilter.FilterSummary.CustomFormat = "C0";
                    modelFilter.FilterSummary.Label = "Max price: ";
                    modelFilter.FilterSummary.PropertyName = "Price";
                }
            }
        }
    }

    public class Car
    {
        [Browsable(false)]
        public int ID { get; set; }

        public string Brand { get; set; }
        public string Model { get; set; }
        public double Liter { get; set; }
        [Browsable(false)]
        public string TransmissAutomatic { get; set; }
        public string Category { get; set; }

        [Browsable(false)]
        public string Description { get; set; }

        [Browsable(false)]
        public byte[] Picture { get; set; }

        [Browsable(false)]
        public double Price { get; set; }
    }
}
